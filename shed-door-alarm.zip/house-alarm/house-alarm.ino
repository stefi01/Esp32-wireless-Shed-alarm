/*
 * ============================================================================
 *  HOUSE ALARM + LCD  —  one indoor controller for TWO sheds
 * ============================================================================
 *
 * Sit this board IN THE HOUSE. It listens to shed 1 and shed 2 over ESP-NOW
 * and shows both on a 16x2 I2C LCD. One siren covers both buildings.
 *
 * Arming is done HERE. You can arm both, or only one (handy when you are
 * working in shed 1 but still want shed 2 protected).
 *
 * LCD (I2C 16x2, default SDA=21 SCL=22)
 * -------------------------------------
 *   Line 1  S1:<status>  S2:<status>
 *           OK / OPEN / PRY / TAMP / DEAD / ---- (not heard yet)
 *   Line 2  arming + which shed is selected, or the alarm text
 *
 * Buttons (to GND, internal pull-ups)
 * -----------------------------------
 *   SELECT       GPIO 14   Cycle focus: ALL -> S1 -> S2
 *   ARM/DISARM   GPIO 13   Hold 1 second: toggle arm for the focus
 *   MUTE         GPIO 15   Silence siren for this event; LCD still shows it
 *   TEST         GPIO 12   Local siren blip
 *
 * Outputs
 * -------
 *   SIREN        GPIO 26   Active buzzer / 5 V siren (HIGH = on)
 *   LED_OK       GPIO 4    Green: slow blink = all disarmed, solid = all
 *                          armed sheds OK, fast blink = waiting
 *   LED_ALARM    GPIO 2    Flashes with the siren
 *
 * The house learns each shed ID (1 then 2) from the first valid packet.
 * Reset this board if you replace a shed ESP32.
 *
 * Libraries: LiquidCrystal I2C (Frank de Brabander)
 * Board: ESP32 Dev Module
 */

#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include "protocol.h"

// #region agent log
static void dbg(const char *hid, const char *loc, const char *msg) {
  Serial.print(F("{\"sessionId\":\"14fac2\",\"hypothesisId\":\""));
  Serial.print(hid);
  Serial.print(F("\",\"location\":\""));
  Serial.print(loc);
  Serial.print(F("\",\"message\":\""));
  Serial.print(msg);
  Serial.print(F("\",\"timestamp\":"));
  Serial.print(millis());
  Serial.println(F("}"));
}
static void dbg2(const char *hid, const char *loc, const char *msg, long a, long b) {
  Serial.print(F("{\"sessionId\":\"14fac2\",\"hypothesisId\":\""));
  Serial.print(hid);
  Serial.print(F("\",\"location\":\""));
  Serial.print(loc);
  Serial.print(F("\",\"message\":\""));
  Serial.print(msg);
  Serial.print(F("\",\"data\":{\"a\":"));
  Serial.print(a);
  Serial.print(F(",\"b\":"));
  Serial.print(b);
  Serial.print(F("},\"timestamp\":"));
  Serial.print(millis());
  Serial.println(F("}"));
}
// #endregion

static const int PIN_SIREN     = 26;
static const int PIN_LED_ALARM = 2;
static const int PIN_LED_OK    = 4;
static const int PIN_BTN_ARM   = 13;
static const int PIN_BTN_MUTE  = 15;
static const int PIN_BTN_TEST  = 12;
static const int PIN_BTN_SEL   = 14;
static const int PIN_SDA       = 21;
static const int PIN_SCL       = 22;

static const unsigned long ARM_HOLD_MS      = 1000;
static const unsigned long MUTE_COOLDOWN_MS = 400;
static const unsigned long TEST_MS          = 1500;
static const unsigned long SIREN_PULSE_MS   = 180;
static const unsigned long LCD_REFRESH_MS   = 300;

enum ShedState : uint8_t {
  ST_OK = 0,
  ST_OPEN,
  ST_PRY,
  ST_TAMPER,
  ST_OFFLINE,
  ST_UNKNOWN
};

enum Focus : uint8_t {
  FOCUS_ALL = 0,
  FOCUS_S1,
  FOCUS_S2
};

struct ShedSlot {
  bool learned;
  bool armed;
  uint8_t mac[6];
  ShedState state;
  AlarmPacket lastPkt;
  unsigned long lastHeardMs;
};

static const uint8_t BROADCAST_ADDR[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

static ShedSlot sheds[SHED_COUNT];
static Focus focus = FOCUS_ALL;
static bool muted = false;
static bool lcdOk = false;
static LiquidCrystal_I2C *lcd = nullptr;

static unsigned long lastSirenToggleMs = 0;
static unsigned long lastLcdMs = 0;
static unsigned long testUntilMs = 0;
static unsigned long armHoldStartMs = 0;
static bool armHolding = false;
static bool sirenPhase = false;

static bool macEqual(const uint8_t *a, const uint8_t *b) {
  return memcmp(a, b, 6) == 0;
}

static void printMac(const uint8_t *mac) {
  char buf[18];
  snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X",
           mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
  Serial.print(buf);
}

static uint8_t idxFromId(uint8_t shedId) {
  return (uint8_t)(shedId - 1);
}

static const char *statusWord(const ShedSlot &s) {
  if (!s.learned) {
    return "----";
  }
  if (s.armed && s.state == ST_OFFLINE) {
    return "DEAD";
  }
  switch (s.state) {
    case ST_OPEN:   return "OPEN";
    case ST_PRY:    return "PRY ";
    case ST_TAMPER: return "TAMP";
    case ST_OFFLINE:return "DEAD";
    case ST_UNKNOWN:return "----";
    default:        return "OK  ";
  }
}

static ShedState stateFromPacket(const AlarmPacket &p) {
  if (p.flags & FLAG_TAMPER) {
    return ST_TAMPER;
  }
  if (p.flags & FLAG_VIBRATION) {
    return ST_PRY;
  }
  if (p.flags & FLAG_DOOR) {
    return ST_OPEN;
  }
  if (p.type == MSG_ALARM) {
    return ST_OPEN;
  }
  return ST_OK;
}

static bool slotAlarms(const ShedSlot &s) {
  return s.armed && s.learned &&
         (s.state == ST_OPEN || s.state == ST_PRY ||
          s.state == ST_TAMPER || s.state == ST_OFFLINE);
}

static bool anyAlarm() {
  return slotAlarms(sheds[0]) || slotAlarms(sheds[1]);
}

static bool anyArmed() {
  return sheds[0].armed || sheds[1].armed;
}

static bool allArmedOk() {
  bool any = false;
  for (uint8_t i = 0; i < SHED_COUNT; i++) {
    if (!sheds[i].armed) {
      continue;
    }
    any = true;
    if (!sheds[i].learned || sheds[i].state != ST_OK) {
      return false;
    }
  }
  return any;
}

static void applyPacket(uint8_t idx, const AlarmPacket &p) {
  ShedSlot &s = sheds[idx];
  s.lastPkt = p;
  s.lastHeardMs = millis();
  s.state = stateFromPacket(p);
}

static void handlePacket(const uint8_t *mac, const uint8_t *data, int len) {
  if (len < (int)sizeof(AlarmPacket)) {
    return;
  }
  AlarmPacket p;
  memcpy(&p, data, sizeof(p));
  if (!packetLooksValid(p)) {
    // #region agent log
    dbg2("B", "house-alarm.ino:handlePacket", "reject", (long)p.shedId, (long)p.type);
    // #endregion
    return;
  }

  uint8_t idx = idxFromId(p.shedId);
  ShedSlot &s = sheds[idx];

  if (!s.learned) {
    memcpy(s.mac, mac, 6);
    s.learned = true;
    Serial.print(F("Learned shed "));
    Serial.print(p.shedId);
    Serial.print(F(" MAC "));
    printMac(s.mac);
    Serial.println();
  } else if (!macEqual(mac, s.mac)) {
    // Same ID from a new board — treat as a replacement sensor.
    memcpy(s.mac, mac, 6);
    Serial.print(F("Replaced shed "));
    Serial.print(p.shedId);
    Serial.print(F(" MAC "));
    printMac(s.mac);
    Serial.println();
  }

  Serial.print(F("RX S"));
  Serial.print(p.shedId);
  Serial.print(F(" type="));
  Serial.print(p.type);
  Serial.print(F(" flags=0x"));
  Serial.print(p.flags, HEX);
  Serial.print(F(" seq="));
  Serial.println(p.seq);

  ShedState prev = s.state;
  applyPacket(idx, p);
  if (slotAlarms(s) && s.state != prev) {
    muted = false;
  }
  // #region agent log
  dbg2("D", "house-alarm.ino:handlePacket", "rx",
       (long)((p.shedId * 1000) + p.flags),
       (long)((s.armed ? 100 : 0) + (slotAlarms(s) ? 10 : 0) + s.state));
  // #endregion
}

#if defined(ESP_ARDUINO_VERSION) && ESP_ARDUINO_VERSION >= ESP_ARDUINO_VERSION_VAL(3, 0, 0)
void onRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  if (info) {
    handlePacket(info->src_addr, data, len);
  }
}
#else
void onRecv(const uint8_t *mac, const uint8_t *data, int len) {
  handlePacket(mac, data, len);
}
#endif

static bool initRadio() {
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  delay(50);

  esp_wifi_set_promiscuous(true);
  esp_wifi_set_channel(RADIO_CHANNEL, WIFI_SECOND_CHAN_NONE);
  esp_wifi_set_promiscuous(false);

  Serial.print(F("House MAC "));
  Serial.println(WiFi.macAddress());

  if (esp_now_init() != ESP_OK) {
    Serial.println(F("esp_now_init failed"));
    return false;
  }
  esp_now_register_recv_cb(onRecv);

  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, BROADCAST_ADDR, 6);
  peer.channel = RADIO_CHANNEL;
  peer.encrypt = false;
  esp_now_add_peer(&peer);
  return true;
}

static uint8_t findLcdAddr() {
  const uint8_t candidates[] = {0x27, 0x3F};
  for (uint8_t i = 0; i < 2; i++) {
    Wire.beginTransmission(candidates[i]);
    if (Wire.endTransmission() == 0) {
      return candidates[i];
    }
  }
  return 0;
}

static void initLcd() {
  Wire.begin(PIN_SDA, PIN_SCL);
  delay(50);
  uint8_t addr = findLcdAddr();
  if (addr == 0) {
    Serial.println(F("No I2C LCD at 0x27 or 0x3F — continuing without display"));
    lcdOk = false;
    return;
  }
  Serial.print(F("LCD at 0x"));
  Serial.println(addr, HEX);
  lcd = new LiquidCrystal_I2C(addr, 16, 2);
  lcd->init();
  lcd->backlight();
  lcd->clear();
  lcd->print(F("Shed 1+2 alarm"));
  lcd->setCursor(0, 1);
  lcd->print(F("Waiting..."));
  lcdOk = true;
}

static void pad16(char *buf) {
  size_t n = strlen(buf);
  while (n < 16) {
    buf[n++] = ' ';
  }
  buf[16] = '\0';
}

static void drawLcd() {
  if (!lcdOk || !lcd) {
    return;
  }
  char line0[17];
  char line1[17];

  snprintf(line0, sizeof(line0), "S1:%s S2:%s",
           statusWord(sheds[0]), statusWord(sheds[1]));

  if (testUntilMs > millis()) {
    snprintf(line1, sizeof(line1), "SIREN TEST");
  } else if (anyAlarm()) {
    const char *who =
        slotAlarms(sheds[0]) && slotAlarms(sheds[1]) ? "S1+S2" :
        slotAlarms(sheds[0]) ? "S1" : "S2";
    const ShedSlot &hot = slotAlarms(sheds[0]) ? sheds[0] : sheds[1];
    snprintf(line1, sizeof(line1), "%s %s %s",
             muted ? "MUTE" : "ALM", who, statusWord(hot));
  } else {
    const char *markAll = (focus == FOCUS_ALL) ? ">" : " ";
    const char *mark1 = (focus == FOCUS_S1) ? ">" : " ";
    const char *mark2 = (focus == FOCUS_S2) ? ">" : " ";
    char a1[4], a2[4];
    strcpy(a1, sheds[0].armed ? "ON" : "off");
    strcpy(a2, sheds[1].armed ? "ON" : "off");
    // >A  >1ON  2off   or similar. Keep to 16 chars.
    snprintf(line1, sizeof(line1), "%sA %s1%s %s2%s",
             markAll, mark1, a1, mark2, a2);
  }

  pad16(line0);
  pad16(line1);
  lcd->setCursor(0, 0);
  lcd->print(line0);
  lcd->setCursor(0, 1);
  lcd->print(line1);
}

static bool btnDown(int pin) {
  return digitalRead(pin) == LOW;
}

static void setArm(uint8_t idx, bool on) {
  sheds[idx].armed = on;
  if (!on && sheds[idx].state == ST_OFFLINE) {
    sheds[idx].state = sheds[idx].learned ? stateFromPacket(sheds[idx].lastPkt) : ST_UNKNOWN;
  }
  Serial.print(F("Shed "));
  Serial.print(idx + 1);
  Serial.println(on ? F(" ARMED") : F(" DISARMED"));
}

static void toggleFocusArm() {
  muted = false;
  if (focus == FOCUS_ALL) {
    bool bothOn = sheds[0].armed && sheds[1].armed;
    setArm(0, !bothOn);
    setArm(1, !bothOn);
  } else if (focus == FOCUS_S1) {
    setArm(0, !sheds[0].armed);
  } else {
    setArm(1, !sheds[1].armed);
  }
  // #region agent log
  dbg2("D", "house-alarm.ino:toggleFocusArm", "arm", sheds[0].armed, sheds[1].armed);
  // #endregion
}

static void serviceButtons() {
  unsigned long now = millis();

  static unsigned long lastSelMs = 0;
  if (btnDown(PIN_BTN_SEL) && (now - lastSelMs) > 250) {
    lastSelMs = now;
    focus = (Focus)((focus + 1) % 3);
    Serial.print(F("Focus "));
    Serial.println(focus == FOCUS_ALL ? F("ALL") : (focus == FOCUS_S1 ? F("S1") : F("S2")));
    while (btnDown(PIN_BTN_SEL)) {
      delay(10);
    }
    drawLcd();
  }

  if (btnDown(PIN_BTN_ARM)) {
    if (!armHolding) {
      armHolding = true;
      armHoldStartMs = now;
    } else if (now - armHoldStartMs >= ARM_HOLD_MS) {
      armHolding = false;
      toggleFocusArm();
      while (btnDown(PIN_BTN_ARM)) {
        delay(10);
      }
      drawLcd();
    }
  } else {
    armHolding = false;
  }

  static unsigned long lastMuteMs = 0;
  if (btnDown(PIN_BTN_MUTE) && (now - lastMuteMs) > MUTE_COOLDOWN_MS) {
    lastMuteMs = now;
    muted = true;
    Serial.println(F("Siren muted for this event"));
    while (btnDown(PIN_BTN_MUTE)) {
      delay(10);
    }
    drawLcd();
  }

  static unsigned long lastTestMs = 0;
  if (btnDown(PIN_BTN_TEST) && (now - lastTestMs) > 500) {
    lastTestMs = now;
    testUntilMs = now + TEST_MS;
    Serial.println(F("Siren TEST"));
    drawLcd();
  }
}

static void serviceSirenAndLeds() {
  unsigned long now = millis();
  bool wantSiren = (testUntilMs > now) || (anyAlarm() && !muted);

  if (wantSiren) {
    if (now - lastSirenToggleMs >= SIREN_PULSE_MS) {
      lastSirenToggleMs = now;
      sirenPhase = !sirenPhase;
    }
    digitalWrite(PIN_SIREN, sirenPhase ? HIGH : LOW);
    digitalWrite(PIN_LED_ALARM, sirenPhase ? HIGH : LOW);
  } else {
    sirenPhase = false;
    digitalWrite(PIN_SIREN, LOW);
    digitalWrite(PIN_LED_ALARM, LOW);
  }

  if (!anyArmed()) {
    digitalWrite(PIN_LED_OK, (now / 400) % 2);
  } else if (anyAlarm()) {
    digitalWrite(PIN_LED_OK, LOW);
  } else if (allArmedOk()) {
    digitalWrite(PIN_LED_OK, HIGH);
  } else {
    digitalWrite(PIN_LED_OK, (now / 120) % 2);
  }
}

void setup() {
  pinMode(PIN_SIREN, OUTPUT);
  pinMode(PIN_LED_ALARM, OUTPUT);
  pinMode(PIN_LED_OK, OUTPUT);
  pinMode(PIN_BTN_ARM, INPUT_PULLUP);
  pinMode(PIN_BTN_MUTE, INPUT_PULLUP);
  pinMode(PIN_BTN_TEST, INPUT_PULLUP);
  pinMode(PIN_BTN_SEL, INPUT_PULLUP);
  digitalWrite(PIN_SIREN, LOW);
  digitalWrite(PIN_LED_ALARM, LOW);
  digitalWrite(PIN_LED_OK, LOW);

  for (uint8_t i = 0; i < SHED_COUNT; i++) {
    sheds[i].learned = false;
    sheds[i].armed = false;
    sheds[i].state = ST_UNKNOWN;
    sheds[i].lastHeardMs = 0;
  }

  Serial.begin(115200);
  delay(200);
  // #region agent log
  dbg("A", "house-alarm.ino:setup", "house-booted");
  // #endregion
  Serial.println(F("House LCD alarm starting (both sheds DISARMED)"));
  Serial.println(F("SELECT = ALL/S1/S2. Hold ARM 1s. MUTE silences. TEST blips siren."));

  initLcd();
  // #region agent log
  dbg2("C", "house-alarm.ino:setup", "lcd", lcdOk, 0);
  // #endregion

  if (!initRadio()) {
    // #region agent log
    dbg("B", "house-alarm.ino:setup", "radio-fail");
    // #endregion
    if (lcdOk) {
      lcd->clear();
      lcd->print(F("Radio fail"));
    }
    while (true) {
      digitalWrite(PIN_LED_ALARM, !digitalRead(PIN_LED_ALARM));
      delay(80);
    }
  }
  // #region agent log
  dbg("B", "house-alarm.ino:setup", "radio-ok");
  // #endregion
}

void loop() {
  serviceButtons();

  unsigned long now = millis();
  for (uint8_t i = 0; i < SHED_COUNT; i++) {
    if (sheds[i].armed && sheds[i].learned &&
        (now - sheds[i].lastHeardMs) >= OFFLINE_AFTER_MS) {
      if (sheds[i].state != ST_OFFLINE) {
        sheds[i].state = ST_OFFLINE;
        muted = false;
        Serial.print(F("Shed "));
        Serial.print(i + 1);
        Serial.println(F(" OFFLINE"));
      }
    }
  }

  serviceSirenAndLeds();

  if (now - lastLcdMs >= LCD_REFRESH_MS) {
    lastLcdMs = now;
    drawLcd();
  }
}
