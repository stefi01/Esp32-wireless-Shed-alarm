/*
 * protocol.h — copy is in shed-sensor/ AND house-alarm/. Keep them identical.
 *
 * Two sheds share one house controller. Each shed board sets SHED_ID to 1 or 2
 * in shed-sensor.ino before you upload.
 *
 * Change ALARM_SECRET to any number you like (not 0). Both copies of this
 * file and every shed board must use the same secret.
 */

#ifndef SHED_ALARM_PROTOCOL_H
#define SHED_ALARM_PROTOCOL_H

#include <Arduino.h>

#define ALARM_SECRET           0xA51C2026UL
#define ALARM_MAGIC            0x53484432UL  // "SHD2" — two-shed packet
#define RADIO_CHANNEL          1
#define SHED_COUNT             2
#define SHED_ID_MIN            1
#define SHED_ID_MAX            2
#define HEARTBEAT_MS           2000UL
#define OFFLINE_AFTER_MS       8000UL
#define VIBRATION_ALARM_MS     250
#define DOOR_DEBOUNCE_MS       40

enum MsgType : uint8_t {
  MSG_HEARTBEAT = 1,
  MSG_ALARM     = 2,
  MSG_CLEAR     = 3
};

enum AlarmFlag : uint8_t {
  FLAG_DOOR      = 1 << 0,
  FLAG_VIBRATION = 1 << 1,
  FLAG_TAMPER    = 1 << 2
};

struct AlarmPacket {
  uint32_t magic;
  uint32_t secret;
  uint16_t seq;
  uint8_t  type;
  uint8_t  flags;
  uint8_t  shedId;       // 1 = shed one, 2 = shed two
  uint8_t  reserved[3];
};

static inline bool packetLooksValid(const AlarmPacket &p) {
  return p.magic == ALARM_MAGIC &&
         p.secret == ALARM_SECRET &&
         p.shedId >= SHED_ID_MIN &&
         p.shedId <= SHED_ID_MAX;
}

#endif
