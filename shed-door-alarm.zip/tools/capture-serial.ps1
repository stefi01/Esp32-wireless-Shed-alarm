# Capture ESP32 Serial JSON debug lines into debug-14fac2.log
# Usage (close Arduino Serial Monitor first):
#   powershell -ExecutionPolicy Bypass -File tools\capture-serial.ps1
#   powershell -ExecutionPolicy Bypass -File tools\capture-serial.ps1 -Port COM5

param(
  [string]$Port = "",
  [int]$Baud = 115200
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$logPath = Join-Path $root "debug-14fac2.log"
$ingest = "http://127.0.0.1:7795/ingest/981b1fbb-53d7-473f-ae83-a72ae625020d"

Add-Type -AssemblyName System.IO.Ports
$ports = [System.IO.Ports.SerialPort]::GetPortNames()
if (-not $ports) {
  Write-Host "No COM ports found. Plug in the HOUSE ESP32 over USB."
  exit 1
}

if (-not $Port) {
  $Port = $ports[-1]
  Write-Host "COM ports: $($ports -join ', '). Using $Port (pass -Port COMx to override)."
}

$serial = New-Object System.IO.Ports.SerialPort $Port, $Baud
$serial.ReadTimeout = 1000
$serial.NewLine = "`n"
$serial.Open()
Write-Host "Capturing $Port at $Baud -> $logPath"
Write-Host "Leave this window open, then power the house ESP32 and run the alarm test."

try {
  while ($true) {
    try {
      $line = $serial.ReadLine()
    } catch {
      continue
    }
    $line = $line.Trim()
    Write-Host $line
    if ($line.StartsWith("{") -and $line.Contains("14fac2")) {
      Add-Content -Path $logPath -Value $line
      try {
        Invoke-RestMethod -Uri $ingest -Method Post -Body $line -ContentType "application/json" -TimeoutSec 2 | Out-Null
      } catch {
      }
    }
  }
} finally {
  if ($serial.IsOpen) { $serial.Close() }
}
