/*
 * ============================================================================
 *  SHED SENSOR  (unit 1 of 2)  —  ESP32 + ESP-NOW
 * ============================================================================
 *
 * Mount this board IN A SHED. Upload the same sketch twice:
 *   - set SHED_ID to 1 for shed one
 *   - set SHED_ID to 2 for shed two
 * Both talk to the single indoor LCD controller.
 *
 * Sensors
 * -------
 *   Magnetic reed switch  GPIO 15   Door closed = magnet present = pin LOW
 *                                   (switch wired between GPIO and GND)
 *   Vibration / shock     GPIO 4    SW-420 style: HIGH while shaking
 *   Case tamper           GPIO 5    Lid switch to GND, pulled up.
 *                                   Leave unconnected if you skip this;
 *                                   INPUT_PULLUP will read "not tampered".
 *
 * The house unit decides whether to sound the siren (arm/disarm lives
 * there on purpose — a thief who finds this box cannot silence the house).
 *
 * Power the shed board from USB 5 V. If someone cuts the power, heartbeats
 * stop and the house unit raises an OFFLINE alarm.
 *
 * Board: ESP32 Dev Module. Open this folder (shed-sensor) in Arduino IDE.
 */

#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include "protocol.h"

// #region agent log
static void dbg2(const char *hid, const char *loc, const char *msg, long a, long b) {
  Serial.print(F("{\"sessionId\":\"14fac2\",\"hypothesisId\":\""));
  Serial.print(hid);
  Serial.print(F("\",\"location\":\""));
  Serial.print(loc);
  Serial.print(F("\",\"message\":\""));
  Serial.print(msg);
  Serial.print(F("\",\"data\":{\"a\":"));
  Serial.print(a);
  Serial.print(F(",\"b\":"));
  Serial.print(b);
  Serial.print(F("},\"timestamp\":"));
  Serial.print(millis());
  Serial.println(F("}"));
}
// #endregion

// ---------------------------------------------------------------------------
// WHICH SHED IS THIS BOARD?
// Upload once with 1, then change to 2 and upload to the other ESP32.
// The indoor LCD labels them S1 and S2. They MUST be different.
// ---------------------------------------------------------------------------
#define SHED_ID  1

#if SHED_ID < 1 || SHED_ID > 2
#error SHED_ID must be 1 (shed one) or 2 (shed two)
#endif

// ---------------------------------------------------------------------------
// Pins — change here if your wiring differs
// ---------------------------------------------------------------------------
static const int PIN_REED      = 15;  // magnetic door contact
static const int PIN_VIBRATION = 4;   // SW-420 digital out
static const int PIN_TAMPER    = 5;   // enclosure lid (optional)
static const int PIN_LED       = 2;   // onboard LED, blinks on each send

// Optional sensors: set to false if that part is not wired yet.
// An unconnected tamper pin would otherwise look like "lid off".
static const bool VIBRATION_ENABLED = true;
static const bool TAMPER_ENABLED    = false;

// Reed: we assume a normally-closed-when-door-shut contact to GND.
// Door OPEN  => pin reads HIGH (pull-up, magnet gone)
// Door SHUT  => pin reads LOW
static const bool REED_OPEN_IS_HIGH = true;

// SW-420 modules usually idle LOW and pulse HIGH when hit.
static const bool VIBRATION_ACTIVE_HIGH = true;

static const uint8_t BROADCAST_ADDR[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

static uint16_t seq = 0;
static bool doorOpen = false;
static bool vibrating = false;
static bool tampered = false;
static bool lastDoorOpen = false;
static bool lastTampered = false;

static unsigned long lastSendMs = 0;
static unsigned long lastReedChangeMs = 0;
static unsigned long vibrationUntilMs = 0;

static bool reedRaw() {
  bool high = digitalRead(PIN_REED) == HIGH;
  return REED_OPEN_IS_HIGH ? high : !high;
}

static bool vibrationRaw() {
  if (!VIBRATION_ENABLED) {
    return false;
  }
  bool high = digitalRead(PIN_VIBRATION) == HIGH;
  return VIBRATION_ACTIVE_HIGH ? high : !high;
}

static bool tamperRaw() {
  if (!TAMPER_ENABLED) {
    return false;
  }
  // Plunger to GND while the lid is ON. Lid off => pin HIGH => TAMPER.
  return digitalRead(PIN_TAMPER) == HIGH;
}

static void fillPacket(AlarmPacket &p, uint8_t type) {
  memset(&p, 0, sizeof(p));
  p.magic = ALARM_MAGIC;
  p.secret = ALARM_SECRET;
  p.seq = ++seq;
  p.type = type;
  p.flags = 0;
  p.shedId = (uint8_t)SHED_ID;
  if (doorOpen)  p.flags |= FLAG_DOOR;
  if (vibrating) p.flags |= FLAG_VIBRATION;
  if (tampered)  p.flags |= FLAG_TAMPER;
}

static void sendPacket(uint8_t type) {
  AlarmPacket p;
  fillPacket(p, type);

  digitalWrite(PIN_LED, HIGH);
  esp_err_t err = esp_now_send(BROADCAST_ADDR, (uint8_t *)&p, sizeof(p));
  digitalWrite(PIN_LED, LOW);

  Serial.print(F("TX shed "));
  Serial.print(SHED_ID);
  Serial.print(' ');
  Serial.print(type == MSG_ALARM ? F("ALARM") : (type == MSG_CLEAR ? F("CLEAR") : F("BEAT")));
  Serial.print(F(" seq="));
  Serial.print(p.seq);
  Serial.print(F(" flags=0x"));
  Serial.print(p.flags, HEX);
  Serial.print(F(" err="));
  Serial.println(err);
  // #region agent log
  dbg2("B", "shed-sensor.ino:sendPacket", "tx", (long)((SHED_ID * 100) + type), (long)err);
  // #endregion

  lastSendMs = millis();
}

#if defined(ESP_ARDUINO_VERSION) && ESP_ARDUINO_VERSION >= ESP_ARDUINO_VERSION_VAL(3, 0, 0)
void onSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  (void)info;
#else
void onSent(const uint8_t *mac, esp_now_send_status_t status) {
  (void)mac;
#endif
  if (status != ESP_NOW_SEND_SUCCESS) {
    Serial.println(F("ESP-NOW send failed (house off, out of range, or channel mismatch)"));
  }
}

static bool initRadio() {
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  delay(50);

  // Lock both boards to the same channel. Without this, ESP-NOW can miss
  // packets because STA mode otherwise picks a channel on its own.
  esp_wifi_set_promiscuous(true);
  esp_wifi_set_channel(RADIO_CHANNEL, WIFI_SECOND_CHAN_NONE);
  esp_wifi_set_promiscuous(false);

  Serial.print(F("Shed MAC "));
  Serial.println(WiFi.macAddress());
  Serial.print(F("This board is SHED "));
  Serial.println(SHED_ID);
  Serial.print(F("ESP-NOW channel "));
  Serial.println(RADIO_CHANNEL);

  if (esp_now_init() != ESP_OK) {
    Serial.println(F("esp_now_init failed"));
    return false;
  }
  esp_now_register_send_cb(onSent);

  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, BROADCAST_ADDR, 6);
  peer.channel = RADIO_CHANNEL;
  peer.encrypt = false;
  if (esp_now_add_peer(&peer) != ESP_OK) {
    Serial.println(F("add broadcast peer failed"));
    return false;
  }
  return true;
}

void setup() {
  pinMode(PIN_REED, INPUT_PULLUP);
  pinMode(PIN_VIBRATION, INPUT);      // SW-420 drives this pin; do not pull it up
  pinMode(PIN_TAMPER, INPUT_PULLUP);
  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, LOW);

  Serial.begin(115200);
  delay(200);
  Serial.print(F("Shed sensor starting — SHED "));
  Serial.println(SHED_ID);
  // #region agent log
  dbg2("E", "shed-sensor.ino:setup", "boot-id", SHED_ID, 0);
  // #endregion

  if (!initRadio()) {
    // Fast blink forever so you can see a radio init failure without Serial.
    while (true) {
      digitalWrite(PIN_LED, !digitalRead(PIN_LED));
      delay(80);
    }
  }

  // Seed the first door state without sending a false alarm at boot.
  delay(20);
  doorOpen = reedRaw();
  tampered = tamperRaw();
  lastDoorOpen = doorOpen;
  lastTampered = tampered;
  lastReedChangeMs = millis();

  sendPacket(doorOpen || tampered ? MSG_ALARM : MSG_HEARTBEAT);
}

void loop() {
  unsigned long now = millis();

  bool reed = reedRaw();
  if (reed != lastDoorOpen) {
    if (now - lastReedChangeMs >= DOOR_DEBOUNCE_MS) {
      lastDoorOpen = reed;
      lastReedChangeMs = now;
      doorOpen = reed;
      Serial.println(doorOpen ? F("Door OPEN") : F("Door closed"));
      // #region agent log
      dbg2("F", "shed-sensor.ino:loop", "door", doorOpen, SHED_ID);
      // #endregion
      sendPacket(doorOpen ? MSG_ALARM : MSG_CLEAR);
    }
  } else {
    lastReedChangeMs = now;
  }

  if (vibrationRaw()) {
    vibrationUntilMs = now + VIBRATION_ALARM_MS;
  }
  bool vibNow = now < vibrationUntilMs;
  if (vibNow && !vibrating) {
    vibrating = true;
    Serial.println(F("Vibration / pry"));
    sendPacket(MSG_ALARM);
  } else if (!vibNow) {
    vibrating = false;
  }

  bool tamp = tamperRaw();
  if (tamp != lastTampered) {
    lastTampered = tamp;
    tampered = tamp;
    Serial.println(tampered ? F("Case TAMPER") : F("Case closed"));
    sendPacket(tampered ? MSG_ALARM : MSG_CLEAR);
  }

  // Heartbeat: house uses this as a "still alive" watchdog.
  if (now - lastSendMs >= HEARTBEAT_MS) {
    bool trouble = doorOpen || vibrating || tampered;
    sendPacket(trouble ? MSG_ALARM : MSG_HEARTBEAT);
  }
}
